from django.apps import AppConfig


class ApoyosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apoyos'
