from django.contrib import admin
from .models import Instructor

admin.site.register(Instructor)