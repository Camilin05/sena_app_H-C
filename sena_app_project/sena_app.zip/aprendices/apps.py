from django.apps import AppConfig


class AprendicesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aprendices'
